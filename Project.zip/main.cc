#include "wordgame.h"

int main() {
    WordGame game;
    game.playGame();

    return 0;
}

